/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.bin.Cliente;

/**
 *
 * @author Lucas
 */
public class Cadastro {
    
    public void create(Cliente p){
    
        Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
        try {
            stmt = con.prepareStatement("INSERT INTO cliente(Nome, Telefone, Celular, Endereço, Numero, Cep) VALUES (?,?,?,?,?,?)");
            stmt.setString(1, p.getNome());            
            stmt.setInt(2, p.getTelefone());
            stmt.setInt(3, p.getCelular());
            stmt.setString(4, p.getEndereco());
            stmt.setInt(5, p.getNumero());
            stmt.setInt(6, p.getCep());
            
            
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Cadastrado com sucesso!");
            
        } catch (SQLException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
}

}
        public List<Cliente> read(){
            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            
        
            List<Cliente> clientes = new ArrayList<>();
            
            try {
            stmt = con.prepareStatement("SELECT * FROM cliente");
            rs = stmt.executeQuery();
            
            while (rs.next()) {                
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("id"));
                cliente.setNome(rs.getString("Nome"));
                cliente.setTelefone(rs.getInt("Telefone"));
                cliente.setCelular(rs.getInt("Celular"));
                cliente.setEndereco(rs.getString("Endereço"));
                cliente.setNumero(rs.getInt("Numero"));
                cliente.setCep(rs.getInt("Cep"));
                clientes.add(cliente);
            }
            
            
                    } catch (SQLException ex) {
            Logger.getLogger(Cadastro.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
                ConnectionFactory.closeConnection(con, stmt, rs);
            }
            return clientes;
        }
        

    public void update(Cliente p){
    
        Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
        try {
            stmt = con.prepareStatement("UPDATE cliente SET Nome = ?, Telefone = ?, Celular = ?, Endereço = ?, Numero = ?, Cep = ? WHERE id = ?");
            stmt.setString(1, p.getNome());            
            stmt.setInt(2, p.getTelefone());
            stmt.setInt(3, p.getCelular());
            stmt.setString(4, p.getEndereco());
            stmt.setInt(5, p.getNumero());
            stmt.setInt(6, p.getCep());
            stmt.setInt(7, p.getId());
            
            
            
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Editado com sucesso!");
            
        } catch (SQLException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
}





}
    public void delete(Cliente p){
    
        Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
        try {
            stmt = con.prepareStatement("DELETE FROM cliente WHERE id = ?");
            stmt.setInt(1, p.getId());
            
            
            
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
            
        } catch (SQLException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
}





}
    
    
    
}